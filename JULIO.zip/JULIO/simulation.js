/**
 * Classes para a Lógica do Hub Logístico
 */

class Delivery {
    constructor(id, originNodeId, destNodeId, graph) {
        this.id = id;
        this.originNodeId = originNodeId;
        this.destNodeId = destNodeId;
        this.status = 'WAITING'; // WAITING, IN_TRANSIT, DELIVERED
        
        // Calcula a rota completa via Dijkstra
        const result = graph.dijkstra(originNodeId, destNodeId);
        this.fullPath = result.path; // Array de IDs de nós
        
        // Separa a rota global em "Pernas" (Legs) baseando-se em Hubs
        this.legs = this.calculateLegs(graph);
        this.currentLegIndex = 0;
        
        // Onde a carga está neste exato momento (fisicamente no chão)
        this.currentNodeId = originNodeId;
        this.lastCourierId = null; // Para penalizar ele mesmo de pegar a encomenda logo depois
        // Indicador visual
        this.domElement = null;
    }

    calculateLegs(graph) {
        const legs = [];
        let currentLeg = [this.fullPath[0]];
        
        for (let i = 1; i < this.fullPath.length; i++) {
            const nodeId = this.fullPath[i];
            const node = graph.nodes.get(nodeId);
            currentLeg.push(nodeId);
            
            // Se passou por um HUB (e não é o destino final), quebra a perna aqui! -> Cross-docking
            if (node.type === 'hub' && i < this.fullPath.length - 1) {
                legs.push([...currentLeg]);
                currentLeg = [nodeId]; // Começa nova perna a partir do Hub
            }
        }
        
        if (currentLeg.length > 1) {
            legs.push(currentLeg);
        }
        
        return legs;
    }

    getCurrentLeg() {
        return this.legs[this.currentLegIndex];
    }
}

class Motoboy {
    constructor(id, startNodeId, graph) {
        this.id = id;
        this.state = 'FREE'; // FREE, TO_PICKUP, DELIVERING
        this.currentNodeId = startNodeId;
        
        const startNode = graph.nodes.get(startNodeId);
        this.lat = startNode.lat;
        this.lng = startNode.lng;
        
        this.currentDelivery = null;
        this.routeToFollow = []; // O caminho atual (nós) que o motoboy deve trilhar
        this.routeIndex = 0;
        
        this.microRoute = [];
        this.microRouteIndex = 0;
        
        // Speed base in coordinate degrees. Using 0.0003 roughly equates to visual speeds for smooth traveling
        this.speed = 0.0003; 
        
        this.marker = null; // Leaflet Marker
    }

    assignPickup(delivery, routeToPickup) {
        this.state = 'TO_PICKUP';
        this.currentDelivery = delivery;
        this.routeToFollow = routeToPickup;
        this.routeIndex = 0;
        this.microRoute = [];
        
        // Se a rota for vazia (já está no node), force pegar no prox frame
        if (this.routeToFollow.length === 0 || (this.routeToFollow.length === 1 && this.routeToFollow[0] === this.currentNodeId)) {
            this.pickupPackage();
        }
    }

    pickupPackage() {
        if (!this.currentDelivery) return;
        this.state = 'DELIVERING';
        this.currentDelivery.status = 'IN_TRANSIT';
        
        // Pega a rota da Perna atual da Entrega
        this.routeToFollow = this.currentDelivery.getCurrentLeg();
        this.routeIndex = 0;
        this.microRoute = [];
        
        window.dispatchEvent(new CustomEvent('log', { detail: `Motoboy ${this.id} coletou pacote ${this.currentDelivery.id}. Indo para próximo ponto.` }));
    }

    dropPackage() {
        if (!this.currentDelivery) return;
        
        const delivery = this.currentDelivery;
        delivery.currentLegIndex++;
        
        // Atualiza a posição da caixa para onde foi largada
        delivery.currentNodeId = this.currentNodeId;
        delivery.lastCourierId = this.id;
        
        if (delivery.currentLegIndex >= delivery.legs.length) {
            delivery.status = 'DELIVERED';
            window.dispatchEvent(new CustomEvent('log', { detail: `📦 Pacote ${delivery.id} ENTREGUE no destino final!`, type: 'success' }));
        } else {
            delivery.status = 'WAITING';
            window.dispatchEvent(new CustomEvent('log', { detail: `🔄 Pacote ${delivery.id} no HUB aguardando transferência.`, type: 'warning' }));
        }
        
        this.currentDelivery = null;
        this.state = 'FREE';
        this.routeToFollow = [];
        this.microRoute = [];
    }

    update(graph) {
        if (this.state === 'FREE' || this.routeToFollow.length === 0) return;

        let targetNodeId = this.routeToFollow[this.routeIndex];
        
        if (targetNodeId === this.currentNodeId && this.routeIndex < this.routeToFollow.length - 1) {
            this.routeIndex++;
            targetNodeId = this.routeToFollow[this.routeIndex];
        } else if (targetNodeId === this.currentNodeId && this.routeIndex === this.routeToFollow.length -1) {
            this.reachTargetNode(targetNodeId);
            return;
        }

        // Se precisamos buscar as ruas para o próximo Node
        if (this.microRoute.length === 0) {
            const edgeList = graph.adjacencyList.get(this.currentNodeId);
            const edge = edgeList ? edgeList.find(e => e.node === targetNodeId) : null;
            
            if (edge && edge.geometry) {
                this.microRoute = [...edge.geometry];
            } else {
                const targetNode = graph.nodes.get(targetNodeId);
                this.microRoute = [[targetNode.lat, targetNode.lng]];
            }
            this.microRouteIndex = 0;
        }

        let remainingDistance = this.speed;
        
        // Consome as frações físicas de curva de rua
        while (remainingDistance > 0 && this.microRouteIndex < this.microRoute.length) {
            const targetLat = this.microRoute[this.microRouteIndex][0];
            const targetLng = this.microRoute[this.microRouteIndex][1];

            const dx = targetLng - this.lng;
            const dy = targetLat - this.lat;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist <= remainingDistance) { // Chegou num nó de dobra da rua
                this.lat = targetLat;
                this.lng = targetLng;
                remainingDistance -= dist;
                this.microRouteIndex++;
            } else { // Viagem na reta
                const vx = (dx / dist) * remainingDistance;
                const vy = (dy / dist) * remainingDistance;
                this.lng += vx;
                this.lat += vy;
                remainingDistance = 0; 
            }
        }

        if (this.microRouteIndex >= this.microRoute.length) {
            this.currentNodeId = targetNodeId;
            this.microRoute = []; // clear
            this.reachTargetNode(this.currentNodeId);
        }
        
        // Atualizar visual do marcador
        if (this.marker) {
            this.marker.setLatLng([this.lat, this.lng]);
        }
    }
    
    reachTargetNode(nodeId) {
        if (this.routeIndex < this.routeToFollow.length - 1) {
            // Vá pro próximo passo da rota
            this.routeIndex++;
        } else {
            // Fim da rota
            if (this.state === 'TO_PICKUP') {
                this.pickupPackage();
            } else if (this.state === 'DELIVERING') {
                this.dropPackage();
            }
        }
    }
}

// Exportar
window.Delivery = Delivery;
window.Motoboy = Motoboy;
