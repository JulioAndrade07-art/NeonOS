// Inicialização do Mapa Leaflet
const map = L.map('map', {
    zoomControl: false // custom zoom se precisar ou usar mouse wheel
}).setView([-19.5935, -46.9442], 14); // Centro de Araxá - MG

// Dark matter layer para visual mais moderno/logístico
L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
    subdomains: 'abcd',
    maxZoom: 20
}).addTo(map);

// Instâncias Globais
const graph = new Graph();
const motoboys = [];
const deliveries = [];
let deliveryCounter = 1;

// Mapeamento visual das ruas e marcadores de base
const markerNodes = {};

async function addStreetRoute(id1, id2) {
    const n1 = graph.nodes.get(id1);
    const n2 = graph.nodes.get(id2);
    
    if (!n1 || !n2) {
        console.error("Missing node id:", id1, id2);
        return;
    }
    
    try {
        const res = await fetch(`https://router.project-osrm.org/route/v1/driving/${n1.lng},${n1.lat};${n2.lng},${n2.lat}?overview=full&geometries=geojson`);
        if (!res.ok) throw new Error("HTTP Error: " + res.status);
        const data = await res.json();
        
        if (data.routes && data.routes[0]) {
            const coords = data.routes[0].geometry.coordinates; // [[lng, lat]]
            const geom = coords.map(c => [c[1], c[0]]); // Leaflet uses [lat, lng]
            const distance = data.routes[0].distance;
            
            graph.addCustomEdge(id1, id2, distance, geom);
        } else {
            graph.addEdge(id1, id2); // fallback
        }
    } catch(e) {
        console.error("OSRM Error", e);
        graph.addEdge(id1, id2); // fallback
    }
}

async function initGraph() {
    // Nós em Araxá - MG
    graph.addNode('R1', 'Pizzaria', 'restaurant', -19.5910, -46.9430);
    graph.addNode('R2', 'Hamburgueria', 'restaurant', -19.5925, -46.9460);
    graph.addNode('H1', 'Hub Centro', 'hub', -19.5940, -46.9400);
    graph.addNode('H2', 'Hub Sul', 'hub', -19.5980, -46.9420);
    graph.addNode('C1', 'Cliente Leste', 'client', -19.5950, -46.9360);
    graph.addNode('C2', 'Cliente Oeste', 'client', -19.5940, -46.9500);
    graph.addNode('C3', 'Cliente Sul', 'client', -19.6000, -46.9400);

    // Feedback visual imediato
    drawNodesOnMap();
    populateUI();

    // Conexões Estritas de Topologia
    // Para FORÇAR o cross-docking, restaurantes NÃO ligam pra cliente. Ligam para os Hubs.
    await Promise.all([
        addStreetRoute('R1', 'H1'),
        addStreetRoute('R2', 'H1'),
        addStreetRoute('H1', 'C1'),
        addStreetRoute('H1', 'C2'),
        addStreetRoute('H1', 'H2'),
        addStreetRoute('H2', 'C3')
    ]);

    // Desenhar Arestas só após a promessa voltar
    drawEdgesOnMap();
    
    // Inicia lógica depois que grafos estiverem montados
    initMotoboys();
    requestAnimationFrame(loop);
}

function drawNodesOnMap() {
    // Desenhar Nós
    graph.nodes.forEach((node, id) => {
        let iconClass = 'marker-client';
        let iconHtml = 'C';
        if (node.type === 'hub') { iconClass = 'marker-hub'; iconHtml = '<i class="fa-solid fa-building-circle-arrow-right"></i>'; }
        if (node.type === 'restaurant') { iconClass = 'marker-restaurant'; iconHtml = '<i class="fa-solid fa-utensils"></i>'; }

        const icon = L.divIcon({
            className: 'custom-icon',
            html: `<div class="custom-marker ${iconClass}" style="width:30px; height:30px;">${iconHtml}
                      <div class="packages-container" id="node-pkg-${id}"></div>
                   </div>`,
            iconSize: [30, 30],
            iconAnchor: [15, 15]
        });

        markerNodes[id] = L.marker([node.lat, node.lng], { icon }).addTo(map);
        markerNodes[id].bindTooltip(`<b>${node.name}</b><br>(Tipo: ${node.type.toUpperCase()})`);
    });
}

function drawEdgesOnMap() {
    // Desenhar Arestas (Linhas)
    const drawnPairs = new Set();
    graph.nodes.forEach((n1, id1) => {
        graph.adjacencyList.get(id1).forEach(edge => {
            const id2 = edge.node;
            const pair = id1 < id2 ? `${id1}-${id2}` : `${id2}-${id1}`;
            
            if (!drawnPairs.has(pair)) {
                drawnPairs.add(pair);
                
                if (edge.geometry) {
                    L.polyline(edge.geometry, {
                        color: 'rgba(0, 210, 255, 0.5)',
                        weight: 4
                    }).addTo(map);
                } else {
                    const n2 = graph.nodes.get(id2);
                    L.polyline([[n1.lat, n1.lng], [n2.lat, n2.lng]], {
                        color: 'rgba(255,255,255,0.2)',
                        weight: 3,
                        dashArray: '5, 5'
                    }).addTo(map);
                }
            }
        });
    });
}

function initMotoboys() {
    // Inicia 3 motoboys livres em diferentes pontos
    const mb1 = new Motoboy('MBOY-1', 'H1', graph);
    const mb2 = new Motoboy('MBOY-2', 'H1', graph);
    const mb3 = new Motoboy('MBOY-3', 'H2', graph);
    
    motoboys.push(mb1, mb2, mb3);

    // Adicionar visualmente
    motoboys.forEach(mb => {
        const icon = L.divIcon({
            className: 'custom-icon',
            html: `<div class="custom-marker marker-motoboy" style="width:24px; height:24px;"><i class="fa-solid fa-motorcycle"></i></div>`,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
        });
        mb.marker = L.marker([mb.lat, mb.lng], { icon, zIndexOffset: 1000 }).addTo(map);
        mb.marker.bindTooltip(`Motoboy ${mb.id}`);
    });
}

// ================= LÓGICA DO CROSS-DOCKING ================= //

function manageDeliveries() {
    // Para todas as entregas WAITING (Ociosas em algum lugar esperando para serem pegas)
    deliveries.forEach(deliv => {
        if (deliv.status === 'WAITING') {
            // Verificar se já tem algum motoboy indo buscar ELA!
            const alreadyAssigned = motoboys.some(mb => mb.currentDelivery === deliv);
            if (alreadyAssigned) return;

            // Achar motoboy mais perto e livre!
            let bestBoy = null;
            let shortestDist = Infinity;
            let routeToPickup = null;

            motoboys.forEach(mb => {
                if (mb.state === 'FREE') {
                    const res = graph.dijkstra(mb.currentNodeId, deliv.currentNodeId);
                    let dist = res.distance;
                    
                    // Se foi esse motoboy que largou a perna anterior, dar penalidade massiva
                    // Isso garante que ele só vai pegar se não houver NENHUM outro motoboy disponível no mapa todo
                    if (mb.id === deliv.lastCourierId) {
                        dist += 100000;
                    }

                    if (dist < shortestDist) {
                        shortestDist = dist;
                        bestBoy = mb;
                        routeToPickup = res.path;
                    }
                }
            });

            if (bestBoy) {
                bestBoy.assignPickup(deliv, routeToPickup);
                addLog(`Motoboy ${bestBoy.id} foi despachado para coletar o pedido #${deliv.id} em ${deliv.currentNodeId}.`);
            }
        }
    });
    
    updateVisualPackages();
}

function updateVisualPackages() {
    // Limpa todos e re-desenha com base em quem está WAITING num Node
    graph.nodes.forEach((_, id) => {
        const pkgs = deliveries.filter(d => d.currentNodeId === id && d.status === 'WAITING');
        const container = document.getElementById(`node-pkg-${id}`);
        if(container) {
            container.innerHTML = pkgs.length > 0 ? `<div class="package-waiting">${pkgs.length}</div>` : '';
        }
    });

    // Atualiza contadores
    document.getElementById('stat-motoboys').innerText = `${motoboys.filter(m=>m.state==='DELIVERING').length} em Rota`;
    document.getElementById('stat-deliveries').innerText = `${deliveries.filter(d=>d.status!=='DELIVERED').length} Ativas`;
}

// ================= GAME LOOP ================= //

let lastTime = 0;
function loop(timestamp) {
    const deltaTime = timestamp - lastTime;
    
    // Roda lógica do HUB
    manageDeliveries();

    // Roda frames dos Motoboys
    motoboys.forEach(mb => mb.update(graph));

    lastTime = timestamp;
    requestAnimationFrame(loop);
}

// ================= UI e EVENTOS ================= //

function populateUI() {
    const selOrigin = document.getElementById('origin-select');
    const selDest = document.getElementById('dest-select');
    
    graph.nodes.forEach((node, id) => {
        if (node.type === 'restaurant' || node.type === 'hub') {
            selOrigin.innerHTML += `<option value="${id}">${node.name}</option>`;
        }
        if (node.type === 'client' || node.type === 'hub') {
            selDest.innerHTML += `<option value="${id}">${node.name}</option>`;
        }
    });
}

document.getElementById('btn-deliver').addEventListener('click', () => {
    const origId = document.getElementById('origin-select').value;
    const destId = document.getElementById('dest-select').value;

    if (origId === destId) {
        alert("A Origem deve ser diferente do Destino.");
        return;
    }

    const dRef = graph.dijkstra(origId, destId);
    if (!dRef || dRef.path.length === 0) {
        alert("Não existe caminho logístico entre esses pontos!");
        return;
    }

    const deliv = new Delivery(String(deliveryCounter).padStart(3, '0'), origId, destId, graph);
    deliveries.push(deliv);
    
    addLog(`Nova entrega #${deliv.id} criada. Passará por ${deliv.legs.length} perna(s).`);
    deliveryCounter++;
});

// Listener Global para Logs
window.addEventListener('log', (e) => {
    addLog(e.detail, e.type);
});

function addLog(msg, type = "info") {
    const logs = document.getElementById('logs-list');
    const div = document.createElement('div');
    div.className = `log-item ${type}`;
    div.innerText = msg;
    logs.appendChild(div);
    // Rolagem para baixo
    logs.scrollTop = logs.scrollHeight;
}

// Start
initGraph();
