/**
 * Classe Graph - Representação de roteamento e nós lógicos.
 * Adaptada para as necessidades de roteamento baseado em menores distâncias.
 */
class Graph {
    constructor() {
        this.nodes = new Map(); // id -> { id, name, type, lat, lng }
        this.adjacencyList = new Map(); // id -> [{ node: id, weight: number }]
    }

    addNode(id, name, type, lat, lng) {
        this.nodes.set(id, { id, name, type, lat, lng });
        this.adjacencyList.set(id, []);
    }

    addCustomEdge(node1, node2, weight, geometry) {
        // Inverte a geometria para o caminho de volta bater certinho nas ruas
        const reverseGeom = [...geometry].reverse();
        
        this.adjacencyList.get(node1).push({ node: node2, weight, geometry });
        this.adjacencyList.get(node2).push({ node: node1, weight, geometry: reverseGeom });
    }

    addEdge(node1, node2) {
        // Calcular distância real aproximada com base nas coordenadas (Fórmula de Haversine ou Pitágoras simples se for pequena escala)
        const n1 = this.nodes.get(node1);
        const n2 = this.nodes.get(node2);
        
        // Simples dist Euclidiana multiplicada para ser o "peso" / tempo estimado
        const weight = Math.sqrt(Math.pow(n1.lat - n2.lat, 2) + Math.pow(n1.lng - n2.lng, 2)) * 10000;
        
        this.adjacencyList.get(node1).push({ node: node2, weight });
        this.adjacencyList.get(node2).push({ node: node1, weight }); // bidirectional
    }

    getDistance(node1, node2) {
        const n1 = this.nodes.get(node1);
        const n2 = this.nodes.get(node2);
        return Math.sqrt(Math.pow(n1.lat - n2.lat, 2) + Math.pow(n1.lng - n2.lng, 2));
    }

    // Retorna { path: Array<nodeId>, distance: number }
    dijkstra(startNode, endNode) {
        const times = {};
        const backtrace = {};
        const pq = new PriorityQueue();
        
        // Inicialização
        this.nodes.forEach((_, nodeId) => {
            times[nodeId] = Infinity;
        });
        
        times[startNode] = 0;
        pq.enqueue([startNode, 0]);
        
        while (!pq.isEmpty()) {
            const shortestStep = pq.dequeue();
            const currentNode = shortestStep[0];
            
            if (currentNode === endNode) {
                let path = [currentNode];
                let lastStep = currentNode;
                while (lastStep !== startNode) {
                    path.unshift(backtrace[lastStep]);
                    lastStep = backtrace[lastStep];
                }
                return { path, distance: times[currentNode] };
            }
            
            this.adjacencyList.get(currentNode).forEach(neighbor => {
                const time = times[currentNode] + neighbor.weight;
                if (time < times[neighbor.node]) {
                    times[neighbor.node] = time;
                    backtrace[neighbor.node] = currentNode;
                    pq.enqueue([neighbor.node, time]);
                }
            });
        }
        
        return { path: [], distance: Infinity }; // Sem caminho
    }
}

class PriorityQueue {
    constructor() {
        this.collection = [];
    }
    enqueue(element) {
        if (this.isEmpty()) {
            this.collection.push(element);
        } else {
            let added = false;
            for (let i = 1; i <= this.collection.length; i++) {
                if (!this.collection[i - 1] || element[1] < this.collection[i - 1][1]) {
                    this.collection.splice(i - 1, 0, element);
                    added = true;
                    break;
                }
            }
            if (!added) {
                this.collection.push(element);
            }
        }
    }
    dequeue() {
        return this.collection.shift();
    }
    isEmpty() {
        return (this.collection.length === 0);
    }
}

// Exportar global
window.Graph = Graph;
